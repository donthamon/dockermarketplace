when window closes

force_shutdown

change text=red

$start

{$}

{  
  [bc1qedq56c7llvxfuzv7gfvcmc8vw7u2syukrpk7ae]

[Create.window:Enable:VSCode:Trace_You

{ Collapse.window
    [track]
[turn.traceable:on

{ 
    Docker Builder
Build script to create images which are based on each other in a certain hierarchy, tag them and push them to a remote repository.
The scenario is a stack of docker images where the 2nd one is made FROM: the 1st, the 3rd one is made FROM: the 2nd, ... and so on.
docker-builder helps to rebuild such a stack from the point where anything might have to changed and therefore a rebuild of an image (and naturally all images on top of that image in such a stack) is blueBrown

}}