#include:hash: [.][/.]

[.]
[[take cache.jar]
[make new java file]



[.]
@DOCKERBUILDER@
[/.]

[.]
Docker Change Name to Running
[/.]

[.]
{
  [server="IP"]
[ports="port:port"]
[user="USER"]
[password="password"]
[/.]



}
[.]
[from server get IP and print]
[from ports do nothing]
[get user=UUID0]
[from password get password and send to docker]
[/.]



[.]
cache=rainbow_scripts

-----

Simple batch scripts to place in the root of your "rainbowcrack-1.6.1-win64" (or whatever version you have) folder to auto-create rainbow tables of almost any available type easily. Thus saving $2700 in the process!

This project contains several scripts. The script title details the hash algorithm, charset, min/max length, and the size of the resulting rainbow table. You will need at LEAST that much space to run the script. Simply double click on the script and let it run. It may run for hours, days, weeks, months, etc. depending on the table size and the hardware you are running it on.

These scripts are meant to simplify the process of rainbow table generation for pentesters who do not yet have the capital to invest in nearly $3000 to buy these tables outright. If you have the time to generate them this gives you a process that is "set it & forget it" and therefore reduces human error. 

Place each batch file (or whichever one you want for the table desired) into the root of your rainbowcrack application directory. Then run simply run the script and walk away.

Once the script is run, it will create all of the tables required. Then it will go through the sorting and processing operations; and finally create an appropriately named folder for the tables and move them into that folder for easy organization. Only one script/table can be run/generated at a time unless you want to have multiple copies of the rainbowcrack program. In this case a different script can be run in each folder to create multiple tables simultaneously; however, I highly doubt that would work properly as CPU is almost totally devoured by a single table generation process even on high powered i7 CPUs. 
[/.]

Code}[.]
{create packet="80"

packet=User

Entername Here=packet

packet=  [  
    {ChangeName:DockerMarketplaceInstaller

{
  [__EDG_RUNTIME_USES_NAMESPACES]
[__has_include]
[docker_contrainer:$]

docker-compose.{#}

docker_marketplace="."

makecollapseable

makecollapseable:[$start

cache:#pragma region 

{$}

[$:
{  
  [bc1qedq56c7llvxfuzv7gfvcmc8vw7u2syukrpk7ae]

[Create.window:Enable:VSCode:Trace_You

{ Collapse.window
    [track]
[turn.traceable:on

{ 
    Docker Builder
Build script to create images which are based on each other in a certain hierarchy, tag them and push them to a remote repository.
The scenario is a stack of docker images where the 2nd one is made FROM: the 1st, the 3rd one is made FROM: the 2nd, ... and so on.
docker-builder helps to rebuild such a stack from the point where anything might have to changed and therefore a rebuild of an image (and naturally all images on top of that image in such a stack)

$start

{$}

{  
  [bc1qedq56c7llvxfuzv7gfvcmc8vw7u2syukrpk7ae]

[Create.window:Enable:VSCode:Trace_You

{ Collapse.window
    [track]
[turn.traceable:on

{ 
    Docker Builder
Build script to create images which are based on each other in a certain hierarchy, tag them and push them to a remote repository.
The scenario is a stack of docker images where the 2nd one is made FROM: the 1st, the 3rd one is made FROM: the 2nd, ... and so on.
docker-builder helps to rebuild such a stack from the point where anything might have to changed and therefore a rebuild of an image (and naturally all images on top of that image in such a stack) is blueBrown

}}

[.]

}
]

#pragma endregion
}
  } ]
      
      }]

      ["."=md5_ascii-32-95_1-8 460GB.bat]

.=cache
[/.]]